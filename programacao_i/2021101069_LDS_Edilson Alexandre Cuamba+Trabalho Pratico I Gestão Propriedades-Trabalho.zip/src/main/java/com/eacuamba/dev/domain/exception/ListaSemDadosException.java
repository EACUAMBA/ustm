package com.eacuamba.dev.domain.exception;

public class ListaSemDadosException extends Exception {
    public ListaSemDadosException(String message){
        super(message);
    }
}
