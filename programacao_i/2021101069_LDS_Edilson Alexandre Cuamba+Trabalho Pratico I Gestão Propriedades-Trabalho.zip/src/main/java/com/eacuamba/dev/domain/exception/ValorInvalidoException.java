package com.eacuamba.dev.domain.exception;

public class ValorInvalidoException extends Exception{
    public  ValorInvalidoException(String message){
       super(message);
    }
}
