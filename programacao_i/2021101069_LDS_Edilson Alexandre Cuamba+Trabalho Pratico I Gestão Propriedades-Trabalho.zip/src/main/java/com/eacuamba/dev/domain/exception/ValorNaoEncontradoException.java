package com.eacuamba.dev.domain.exception;

public class ValorNaoEncontradoException extends Exception{
    public ValorNaoEncontradoException(String message){
        super(message);
    }
}
