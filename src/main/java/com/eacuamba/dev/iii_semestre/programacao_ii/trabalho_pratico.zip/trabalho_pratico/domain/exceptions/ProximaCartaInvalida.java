/*
 * Copyright (c) Edilson Alexandre Cuamba - 4 - 6 - 2022
 */

package com.eacuamba.dev.iii_semestre.programacao_ii.trabalho_pratico.domain.exceptions;

public class ProximaCartaInvalida extends Exception{
    public ProximaCartaInvalida(String msg){
        super(msg);
    }
}
