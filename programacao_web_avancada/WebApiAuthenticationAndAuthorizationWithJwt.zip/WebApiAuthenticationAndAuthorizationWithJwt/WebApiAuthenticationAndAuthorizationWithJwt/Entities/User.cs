﻿using Microsoft.AspNetCore.Identity;

namespace WebApiAuthenticationAndAuthorizationWithJwt.Entities
{
    public class User : IdentityUser
    {
    }
}