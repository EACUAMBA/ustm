﻿using Microsoft.AspNetCore.Mvc;
using sageb.Database;

namespace sageb.Controllers.Administrator.Book;

public class BookController : Controller
{
    private readonly SqliteDbContext _sqliteDbContext;
    private readonly ILogger<AdministratorController> _logger;

    public BookController(
        SqliteDbContext sqliteDbContext,
        ILogger<AdministratorController> logger)
    {
        _sqliteDbContext = sqliteDbContext;
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<BookModel> bookModelList = this._sqliteDbContext.Books.ToList().Select(this.ToBookModel).ToList();

        return View("~/Views/Administrator/Book/Index.cshtml", bookModelList);
    }

    public IActionResult CreateBook()
    {
        return View("~/Views/Administrator/Book/CreateBook.cshtml");
    }

    [HttpPost]
    public IActionResult CreateBook(List<IFormFile> files, BookModel bookModel)
    {
        _logger.LogInformation("Saving Book {Book}", bookModel);

        if (!ModelState.IsValid)
        {
            return this.CreateBook();
        }

        Database.Entities.Book book = new Database.Entities.Book();
        book.Title = bookModel.Title;
        book.Author = bookModel.Author;
        book.Quantity = bookModel.Quantity;
        book.PageQuantity = bookModel.PageQuantity;
        book.PublishDate = bookModel.PublishDate;
        
        using (var memoryStream = new MemoryStream())
        {
            IFormFile formFile = bookModel.CoverImageBase64;
            formFile.OpenReadStream().CopyTo(memoryStream);
            byte[] bytes = memoryStream.ToArray();
            book.CoverImageBase64 ="data:" + formFile.ContentType + ";base64," + Convert.ToBase64String(bytes);
        }

        _sqliteDbContext.Books.Add(book);
        _sqliteDbContext.SaveChanges();

        return RedirectToAction(actionName: "Index", controllerName: "Book");
    }


    [HttpGet]
    public IActionResult DeleteBook(int id)
    {
        _sqliteDbContext.Books
            .Where(x => x.Id == id)
            .ToList()
            .ForEach(x => _sqliteDbContext.Books.Remove(x));

        _sqliteDbContext.SaveChanges();

        return RedirectToAction(actionName: "Index", controllerName: "Book");
    }
    
    public IActionResult EditBook(int bookId)
    {
        Database.Entities.Book book = this._sqliteDbContext.Books.FirstOrDefault(book => book.Id.Equals(bookId))!;
        
        return View("~/Views/Administrator/Book/EditBook.cshtml", this.ToBookModel(book));
    }

    [HttpPost]
    public IActionResult EditBook(int bookId, BookModel bookModel)
    {
        _logger.LogInformation("Saving Book {Book}", bookModel);

        if (!ModelState.IsValid)
        {
            return this.CreateBook();
        }

        Database.Entities.Book book = this._sqliteDbContext.Books.FirstOrDefault(book => book.Id.Equals(bookId))!;;
        book.Title = bookModel.Title;
        book.Author = bookModel.Author;
        book.Quantity = bookModel.Quantity;
        book.PageQuantity = bookModel.PageQuantity;
        book.PublishDate = bookModel.PublishDate;
        
        using (var memoryStream = new MemoryStream())
        {
            IFormFile formFile = bookModel.CoverImageBase64;
            formFile.OpenReadStream().CopyTo(memoryStream);
            byte[] bytes = memoryStream.ToArray();
            book.CoverImageBase64 ="data:" + formFile.ContentType + ";base64," + Convert.ToBase64String(bytes);
        }

        _sqliteDbContext.Books.Update(book);
        _sqliteDbContext.SaveChanges();

        return RedirectToAction(actionName: "Index", controllerName: "Book");
    }

    public BookModel ToBookModel(Database.Entities.Book book)
    {
        return new BookModel()
        {
            Id = book.Id,
            Title = book.Title,
            Author = book.Author,
            Quantity = book.Quantity,
            PageQuantity = book.PageQuantity,
            PublishDate = book.PublishDate,
            CoverImageBase642 = book.CoverImageBase64
        };
    }
    
}