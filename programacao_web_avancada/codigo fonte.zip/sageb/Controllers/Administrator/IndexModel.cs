﻿namespace sageb.Controllers.Administrator;

public class IndexModel
{
    public int? BooksCount { get; set; }
}