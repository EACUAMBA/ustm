﻿namespace sageb.Controllers.Administrator.BookOrder;

public class IndexModel
{
    public List<BookOrderModel> BookOrderModels { get; set; } = new List<BookOrderModel>();
}