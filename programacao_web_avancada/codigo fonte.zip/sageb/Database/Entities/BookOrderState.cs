﻿namespace sageb.Database.Entities;

public enum BookOrderState
{
    Pending,
    Approved,
    Refused,
    BookGiven,
    BookReturned
}