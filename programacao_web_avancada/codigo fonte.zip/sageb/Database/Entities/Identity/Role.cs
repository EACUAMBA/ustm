﻿using Microsoft.AspNetCore.Identity;

namespace sageb.Database.Entities.Identity
{
    public class Role : IdentityRole
    {
    }
}
