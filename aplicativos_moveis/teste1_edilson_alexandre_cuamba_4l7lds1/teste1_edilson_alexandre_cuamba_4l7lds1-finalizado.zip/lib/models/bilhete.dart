class Bilhete{
  int? id;
  String? nome;
  String? data;
  String? localizacao;
  String? preco;

  Bilhete({this.nome, this.data, this.localizacao, this.preco});
}