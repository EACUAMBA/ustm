class Imovel{
  int? id;
  String? tipo;
  String? nr;
  String? imgUrl;
  String? loc;

  Imovel({this.tipo, this.nr, this.imgUrl, this.loc});
}